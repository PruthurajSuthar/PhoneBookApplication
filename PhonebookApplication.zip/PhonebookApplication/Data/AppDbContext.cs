﻿namespace PhonebookApplication.Data
{
    public class AppDbContext
    {
    }
}
